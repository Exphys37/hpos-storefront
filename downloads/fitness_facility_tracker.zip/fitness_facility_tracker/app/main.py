from fastapi import FastAPI, Form
from fastapi.responses import HTMLResponse, RedirectResponse, PlainTextResponse
import csv
import io
import json
from pathlib import Path
from datetime import datetime

app = FastAPI(title="Fitness Facility Tracker", version="1.0")

DATA_FILE = Path("facility_sessions.json")
LICENSE_FILE = Path("license/license_status.json")


def load_license():
    if not LICENSE_FILE.exists():
        return {
            "required": True,
            "valid": False,
            "status": "missing",
            "message": "License file not found."
        }

    try:
        license_data = json.loads(LICENSE_FILE.read_text())
    except Exception:
        return {
            "required": True,
            "valid": False,
            "status": "invalid",
            "message": "License file could not be read."
        }

    status = license_data.get("status")
    valid = status in {"active", "valid"}
    return {
        "required": True,
        "valid": valid,
        "status": status or "unknown",
        "type": license_data.get("type", "local_key"),
        "license_id": license_data.get("license_id"),
        "customer_id": license_data.get("customer_id"),
        "project_name": license_data.get("project_name", "fitness_facility_tracker"),
        "message": "License is active." if valid else "License is not active."
    }


def license_is_valid():
    return bool(load_license().get("valid"))



def load_data():
    if DATA_FILE.exists():
        try:
            return json.loads(DATA_FILE.read_text())
        except Exception:
            return {"active": [], "completed": []}
    return {"active": [], "completed": []}


def save_data(data):
    DATA_FILE.write_text(json.dumps(data, indent=2))


def minutes_between(start, end):
    try:
        start_dt = datetime.fromisoformat(start)
        end_dt = datetime.fromisoformat(end)
        return round((end_dt - start_dt).total_seconds() / 60, 1)
    except Exception:
        return 0


@app.get("/", response_class=HTMLResponse)
def home():
    if not license_is_valid():
        license_info = load_license()
        return f"""
        <!doctype html>
        <html>
        <head><title>License Required</title></head>
        <body style="font-family: Arial, sans-serif; margin: 2rem;">
          <h1>License Required</h1>
          <p>{license_info.get("message", "A valid license is required.")}</p>
          <form method="post" action="/license/activate">
            <button type="submit" style="background:#0f172a;color:white;padding:10px 14px;border:0;border-radius:10px;font-weight:bold;cursor:pointer;">
              Activate License
            </button>
          </form>
          <p><a href="/license/status">View license status</a></p>
        </body>
        </html>
        """
    license_info = load_license()
    license_status = license_info.get("status", "unknown")
    license_valid = license_info.get("valid", False)
    license_badge = "ACTIVE" if license_valid else "NOT ACTIVE"
    license_message = license_info.get("message", "License status unavailable.")
    license_id = license_info.get("license_id") or "unassigned"
    customer_id = license_info.get("customer_id") or "unassigned"

    data = load_data()
    active = data.get("active", [])
    completed = list(reversed(data.get("completed", [])[-20:]))

    active_rows = ""
    for i, item in enumerate(active):
        active_rows += f"""
        <tr>
          <td>{item.get('name','')}</td>
          <td>{item.get('check_in','')}</td>
          <td>
            <form method="post" action="/checkout">
              <input type="hidden" name="index" value="{i}" />
              <button type="submit">Check Out</button>
            </form>
          </td>
        </tr>
        """

    completed_rows = ""
    for item in completed:
        completed_rows += f"""
        <tr>
          <td>{item.get('name','')}</td>
          <td>{item.get('check_in','')}</td>
          <td>{item.get('check_out','')}</td>
          <td>{item.get('duration_minutes', 0)}</td>
        </tr>
        """

    return f"""
    <!doctype html>
    <html>
    <head>
      <title>Fitness Facility Tracker</title>
      <style>
        body {{ font-family: Arial, sans-serif; margin: 0; background: #f4f6f8; color: #0f172a; }}
        header {{ background: #0f172a; color: white; padding: 24px 32px; }}
        main {{ max-width: 1100px; margin: 24px auto; padding: 0 16px; }}
        .grid {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }}
        .card {{ background: white; border-radius: 14px; padding: 20px; box-shadow: 0 4px 16px rgba(15,23,42,.08); margin-bottom: 18px; }}
        .metric {{ font-size: 34px; font-weight: bold; margin-top: 8px; }}
        .license-card {{ border-left: 6px solid #0f172a; }}
        .badge {{ display: inline-block; padding: 6px 10px; border-radius: 999px; background: #dcfce7; color: #166534; font-weight: bold; font-size: 12px; letter-spacing: .04em; }}
        .muted {{ color: #64748b; }}
        input {{ padding: 10px; border: 1px solid #cbd5e1; border-radius: 8px; margin-right: 8px; }}
        button, a.button {{ background: #0f172a; color: white; padding: 10px 14px; border: 0; border-radius: 10px; text-decoration: none; font-weight: bold; cursor: pointer; }}
        table {{ width: 100%; border-collapse: collapse; }}
        th, td {{ text-align: left; padding: 10px; border-bottom: 1px solid #e2e8f0; }}
        th {{ color: #475569; }}
      </style>
    </head>
    <body>
      <header>
        <h1>Fitness Facility Tracker</h1>
        <p>Local-first check-in/check-out and facility usage reporting.</p>
      </header>
      <main>
        <section class="card license-card">
          <h2>License Status <span class="badge">{license_badge}</span></h2>
          <p>{license_message}</p>
          <p class="muted">Status: {license_status} · License ID: {license_id} · Customer ID: {customer_id}</p>
          <p><a class="button" href="/license/status">View License JSON</a></p>
        </section>

        <section class="grid">
          <div class="card"><div>Active Users</div><div class="metric">{len(active)}</div></div>
          <div class="card"><div>Completed Sessions</div><div class="metric">{len(data.get('completed', []))}</div></div>
          <div class="card"><div>Recent Sessions</div><div class="metric">{len(completed)}</div></div>
        </section>

        <section class="card">
          <h2>Check In User</h2>
          <form method="post" action="/checkin">
            <input name="name" placeholder="User name" required />
            <button type="submit">Check In</button>
          </form>
        </section>

        <section class="card">
          <h2>Active Users</h2>
          <table>
            <thead><tr><th>Name</th><th>Check-In Time</th><th>Action</th></tr></thead>
            <tbody>{active_rows}</tbody>
          </table>
        </section>

        <section class="card">
          <h2>Recent Completed Sessions</h2>
          <p><a class="button" href="/export.csv">Export CSV</a></p>
          <table>
            <thead><tr><th>Name</th><th>Check In</th><th>Check Out</th><th>Minutes</th></tr></thead>
            <tbody>{completed_rows}</tbody>
          </table>
        </section>
      </main>
    </body>
    </html>
    """


@app.post("/checkin")
def checkin(name: str = Form(...)):
    data = load_data()
    data.setdefault("active", []).append({
        "name": name.strip(),
        "check_in": datetime.utcnow().isoformat()
    })
    save_data(data)
    return RedirectResponse(url="/", status_code=303)


@app.post("/checkout")
def checkout(index: int = Form(...)):
    data = load_data()
    active = data.setdefault("active", [])
    completed = data.setdefault("completed", [])

    if 0 <= index < len(active):
        item = active.pop(index)
        item["check_out"] = datetime.utcnow().isoformat()
        item["duration_minutes"] = minutes_between(item.get("check_in", ""), item["check_out"])
        completed.append(item)
        save_data(data)

    return RedirectResponse(url="/", status_code=303)


@app.get("/export.csv")
def export_csv():
    data = load_data()
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=["name", "check_in", "check_out", "duration_minutes"])
    writer.writeheader()
    for item in data.get("completed", []):
        writer.writerow({
            "name": item.get("name", ""),
            "check_in": item.get("check_in", ""),
            "check_out": item.get("check_out", ""),
            "duration_minutes": item.get("duration_minutes", 0)
        })
    return PlainTextResponse(output.getvalue(), media_type="text/csv")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/system/info")
def system_info():
    return {
        "deployment_type": "hp_os_managed",
        "mode": "local_first",
        "status": "operational",
        "product": "fitness_facility_tracker"
    }


@app.get("/license/status")
def license_status():
    return load_license()



@app.post("/license/activate")
def activate_license():
    # In real system this would validate signature
    license_path = Path("license/license_status.json")
    if not license_path.exists():
        return {"status": "error", "message": "License file missing"}

    try:
        data = json.loads(license_path.read_text())
    except Exception:
        return {"status": "error", "message": "Invalid license file"}

    data["status"] = "active"
    license_path.write_text(json.dumps(data, indent=2))

    return {"status": "success", "message": "License activated"}
