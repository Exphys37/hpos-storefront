ROLLBACK SUPPORT
================

This bundle includes a rollback scaffold.

Current behavior:
- rollback tracking is supported by HP-OS support workflows
- this scaffold is intended for manual recovery operations
- automated installer rollback is not yet enabled

Recommended rollback procedure:
1. stop the running service
2. restore the last known-good bundle or deployment snapshot
3. reinstall dependencies if required
4. restart the service
5. record the rollback artifact and reason in HP-OS support

Files in this directory:
- rollback.sh
- README_ROLLBACK.txt
