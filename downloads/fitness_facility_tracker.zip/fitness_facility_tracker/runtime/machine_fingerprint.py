import hashlib
import json
import os
import platform
import socket
from pathlib import Path

def collect_machine_identity() -> dict:
    return {
        "hostname": socket.gethostname(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "python_version": platform.python_version(),
        "user": os.environ.get("USER") or os.environ.get("USERNAME") or "unknown",
    }

def generate_machine_fingerprint() -> str:
    identity = collect_machine_identity()
    payload = json.dumps(identity, sort_keys=True).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()

if __name__ == "__main__":
    print(generate_machine_fingerprint())
