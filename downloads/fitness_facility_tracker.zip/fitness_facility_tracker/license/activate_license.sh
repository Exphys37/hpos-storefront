#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

ACTIVATION_INPUT="${1:-}"
STATUS_FILE="license_status.json"

if [ -z "$ACTIVATION_INPUT" ]; then
  echo "USAGE: ./activate_license.sh <LICENSE_KEY_OR_LICENSE_FILE>"
  exit 1
fi

if [ -f "$ACTIVATION_INPUT" ]; then
  ACTIVATION_INPUT="$ACTIVATION_INPUT" python3 - <<'PYACTFILE'
import hashlib
import hmac
import json
import os
from datetime import datetime, timezone
from pathlib import Path

LICENSE_SIGNING_SECRET = "HPOS_DEMO_SECRET_V1"

def canonical_license_payload(payload: dict) -> str:
    data = {
        "license_key": str(payload.get("license_key", "")),
        "license_tier": str(payload.get("license_tier", "")),
    }
    return json.dumps(data, sort_keys=True, separators=(",", ":"))

def compute_license_signature(license_key: str, license_tier: str) -> str:
    message = canonical_license_payload({
        "license_key": license_key,
        "license_tier": license_tier,
    }).encode("utf-8")
    digest = hmac.new(
        LICENSE_SIGNING_SECRET.encode("utf-8"),
        message,
        hashlib.sha256,
    ).hexdigest()
    return f"HPOS-HMAC-SHA256-{digest}"

def verify_license_payload(payload: dict) -> bool:
    required = ["license_key", "license_tier", "signature"]
    missing = [key for key in required if key not in payload]
    if missing:
        print(f"ACTIVATION_FAILED: missing license fields: {', '.join(missing)}")
        raise SystemExit(3)

    actual = str(payload.get("signature", ""))
    if not actual.startswith("HPOS-HMAC-SHA256-"):
        print("ACTIVATION_FAILED: invalid signature format")
        raise SystemExit(4)

    expected = compute_license_signature(
        str(payload.get("license_key", "")),
        str(payload.get("license_tier", "")),
    )
    if not hmac.compare_digest(actual, expected):
        print("ACTIVATION_FAILED: signature verification failed")
        raise SystemExit(5)
    return True

license_path = Path(os.environ["ACTIVATION_INPUT"])
status_path = Path("license_status.json")
payload = json.loads(license_path.read_text())

verify_license_payload(payload)

if status_path.exists():
    data = json.loads(status_path.read_text())
else:
    data = {}

data["status"] = "activated"
data["license_key"] = payload["license_key"]
data["activated_at"] = datetime.now(timezone.utc).isoformat()
data["activation_mode"] = "signed_license_file"
data["license_tier"] = payload["license_tier"]
data["license_signature"] = payload["signature"]
data["license_source_file"] = str(license_path)

status_path.write_text(json.dumps(data, indent=2))
print("ACTIVATION_OK")
PYACTFILE
else
  LICENSE_KEY="$ACTIVATION_INPUT"

  case "$LICENSE_KEY" in
    HPOS-SECURE-*)
      ;;
    *)
      echo "ACTIVATION_FAILED: invalid license key format"
      exit 2
      ;;
  esac

  LICENSE_KEY="$LICENSE_KEY" python3 - <<'PYACTKEY'
import json
import os
from datetime import datetime, timezone
from pathlib import Path

license_key = os.environ["LICENSE_KEY"]
status_path = Path("license_status.json")

if status_path.exists():
    data = json.loads(status_path.read_text())
else:
    data = {}

data["status"] = "activated"
data["license_key"] = license_key
data["activated_at"] = datetime.now(timezone.utc).isoformat()
data["activation_mode"] = "offline_key"
data["license_tier"] = "secured_bundle_placeholder"
data["license_signature"] = None
data["license_source_file"] = None

status_path.write_text(json.dumps(data, indent=2))
print("ACTIVATION_OK")
PYACTKEY
fi
