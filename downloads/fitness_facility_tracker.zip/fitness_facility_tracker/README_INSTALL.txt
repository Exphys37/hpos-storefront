INSTALLATION
============

Project: fitness_facility_tracker

This export currently contains:
- validated source bundle
- runtime/ directory scaffold
- config/ directory scaffold
- install.sh bootstrap script

Install-time artifacts:
- run.sh
- .installed_hp_os

Planned next upgrades:
- dependency/bootstrap installer
- license activation
- machine binding
- production packaging modes
