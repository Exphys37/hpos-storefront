#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

PROJECT_NAME="fitness_facility_tracker"
VENV_DIR=".venv"
INSTALL_MARKER=".installed_hp_os"

chmod +x install.sh || true

mkdir -p runtime
mkdir -p config

PYTHON_BIN=""
if command -v python3 >/dev/null 2>&1; then
  PYTHON_BIN="python3"
elif command -v python >/dev/null 2>&1; then
  PYTHON_BIN="python"
else
  echo "ERROR: Python is required but was not found."
  exit 1
fi

if [ ! -d "$VENV_DIR" ]; then
  "$PYTHON_BIN" -m venv "$VENV_DIR"
fi

if [ -x "$VENV_DIR/bin/python" ]; then
  VENV_PY="$VENV_DIR/bin/python"
  VENV_PIP="$VENV_DIR/bin/pip"
else
  echo "ERROR: virtual environment creation failed."
  exit 1
fi

"$VENV_PY" -m pip install --upgrade pip >/dev/null 2>&1 || true

  if [ -f "requirements.txt" ]; then
    "$VENV_PIP" install -r requirements.txt
  else
    echo "No requirements.txt found. Skipping dependency install."
    if [ -f "DEPENDENCIES_REQUIRED.txt" ]; then
      echo "WARNING: dependency manifest is missing for this bundle."
      echo "See DEPENDENCIES_REQUIRED.txt before attempting launch."
    fi
  fi

  if [ -f "runtime/machine_fingerprint.py" ] && [ -f "config/machine_binding.json" ]; then
    CURRENT_FP="$("$VENV_PY" runtime/machine_fingerprint.py)"
    CURRENT_FP="$CURRENT_FP" "$VENV_PY" - <<'PYBIND'
import json
import os
from pathlib import Path

path = Path("config/machine_binding.json")
data = json.loads(path.read_text())
data["machine_fingerprint"] = os.environ["CURRENT_FP"]
if data.get("binding_enabled") and data.get("binding_status") == "unbound":
    data["binding_status"] = "bound"
path.write_text(json.dumps(data, indent=2))
PYBIND
  fi

  cat > run.sh <<'RUNEOF'
  #!/usr/bin/env bash
  set -e
  SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
  cd "$SCRIPT_DIR"

  if [ ! -x ".venv/bin/python" ]; then
    echo "Environment not installed. Run ./install.sh first."
    exit 1
  fi

  if [ -f "DEPENDENCIES_REQUIRED.txt" ] && [ ! -f "requirements.txt" ]; then
    echo "RUNTIME_WARNING: dependency manifest is missing for this bundle."
    echo "Review DEPENDENCIES_REQUIRED.txt and add project dependencies before launch."
  fi

  if [ -f "config/machine_binding.json" ] && [ -f "license/license_status.json" ]; then
    echo "SECURED MODE: checking license and machine binding"
    ".venv/bin/python" - <<'PYCHECK'
import hashlib
import hmac
import json
from pathlib import Path
import sys

LICENSE_SIGNING_SECRET = "HPOS_DEMO_SECRET_V1"

def canonical_license_payload(payload: dict) -> str:
    data = {
        "license_key": str(payload.get("license_key", "")),
        "license_tier": str(payload.get("license_tier", "")),
    }
    return json.dumps(data, sort_keys=True, separators=(",", ":"))

def compute_license_signature(license_key: str, license_tier: str) -> str:
    message = canonical_license_payload({
        "license_key": license_key,
        "license_tier": license_tier,
    }).encode("utf-8")
    digest = hmac.new(
        LICENSE_SIGNING_SECRET.encode("utf-8"),
        message,
        hashlib.sha256,
    ).hexdigest()
    return f"HPOS-HMAC-SHA256-{digest}"

binding = json.loads(Path("config/machine_binding.json").read_text())
license_status = json.loads(Path("license/license_status.json").read_text())

if binding.get("binding_enabled") and binding.get("binding_status") != "bound":
    print("LAUNCH_BLOCKED: machine is not bound")
    sys.exit(2)

if license_status.get("status") != "activated":
    print("LAUNCH_BLOCKED: license is not activated")
    sys.exit(3)

license_key = str(license_status.get("license_key") or "")
license_tier = str(license_status.get("license_tier") or "")
license_signature = str(license_status.get("license_signature") or "")

if not license_key or not license_tier or not license_signature:
    print("LAUNCH_BLOCKED: license payload is incomplete")
    sys.exit(4)

expected = compute_license_signature(license_key, license_tier)
if not hmac.compare_digest(license_signature, expected):
    print("LAUNCH_BLOCKED: license signature verification failed")
    sys.exit(5)
PYCHECK
  fi

  if [ -f "artifact_signature.json" ]; then
    ".venv/bin/python" - <<'PYART'
import json
from pathlib import Path
import sys

sig_path = Path("artifact_signature.json")
manifest_path = Path("export_manifest.json")

if not manifest_path.exists():
    print("LAUNCH_BLOCKED: export manifest is missing")
    sys.exit(6)

signature = json.loads(sig_path.read_text())
manifest = json.loads(manifest_path.read_text())

expected_scheme = "hpos-export-fingerprint-v1"
actual_scheme = str(signature.get("scheme") or "")
sig_fp = str(signature.get("export_fingerprint") or "")
manifest_fp = str(manifest.get("export_fingerprint") or "")

if actual_scheme != expected_scheme:
    print("LAUNCH_BLOCKED: artifact signature scheme is invalid")
    sys.exit(7)

if not sig_fp or not manifest_fp:
    print("LAUNCH_BLOCKED: artifact fingerprint data is incomplete")
    sys.exit(8)

if sig_fp != manifest_fp:
    print("LAUNCH_BLOCKED: artifact fingerprint verification failed")
    sys.exit(9)
PYART
  fi

  export PYTHONPATH="$SCRIPT_DIR${PYTHONPATH:+:$PYTHONPATH}"
  if grep -q "FastAPI(" app/main.py 2>/dev/null; then
    exec ".venv/bin/uvicorn" app.main:app --host 0.0.0.0 --port 8030
  else
    exec ".venv/bin/python" app/main.py
  fi
RUNEOF

chmod +x run.sh

cat > "$INSTALL_MARKER" <<EOF
project=$PROJECT_NAME
installed_at=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
python=$("$VENV_PY" --version 2>&1)
EOF

echo "Installation complete for $PROJECT_NAME"
echo "Launcher created: ./run.sh"
echo "Install marker written: $INSTALL_MARKER"
