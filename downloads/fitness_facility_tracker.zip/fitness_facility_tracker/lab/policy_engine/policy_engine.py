from typing import Dict, Any


class PolicyViolation(Exception):
    pass


class PolicyEngine:

    def evaluate(self, rule_name: str, context: Dict[str, Any]) -> None:
        if rule_name == "program.activate":
            self._program_activate(context)
        elif rule_name == "program.approve":
            self._program_approve(context)
        else:
            raise PolicyViolation(f"Unknown policy rule: {rule_name}")

    def _program_activate(self, context: Dict[str, Any]) -> None:
        clearance = context.get("clearance")
        status = context.get("status")

        if status != "approved":
            raise PolicyViolation("Program must be approved before activation")

        if clearance != "full":
            raise PolicyViolation("Athlete not cleared")

    def _program_approve(self, context: Dict[str, Any]) -> None:
        status = context.get("status")

        if status != "draft":
            raise PolicyViolation("Only draft programs can be approved")
