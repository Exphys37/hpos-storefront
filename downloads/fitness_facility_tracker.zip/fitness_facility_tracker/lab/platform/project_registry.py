from typing import Dict
from registry.entity_handlers import entity_handler_registry

class ProjectRegistry:

    def __init__(self):
        self.projects: Dict[str, Dict] = {}

    def register_project(self, name: str, entities: Dict):
        self.projects[name] = entities

    def list_projects(self):
        return self.projects

project_registry = ProjectRegistry()
