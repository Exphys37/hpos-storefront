from dataclasses import dataclass
from typing import Dict


@dataclass
class ProjectDefinition:
    name: str
    entities: Dict[str, str]  # entity_type -> description
    autonomy_profile: Dict[str, str]  # event_type -> autonomy_level


class ProjectRegistry:
    def __init__(self):
        self._projects: Dict[str, ProjectDefinition] = {}

    def register(self, project: ProjectDefinition):
        self._projects[project.name] = project

    def get(self, name: str) -> ProjectDefinition:
        return self._projects.get(name)

    def all(self):
        return self._projects.values()


project_registry = ProjectRegistry()

project_registry.register(
    ProjectDefinition(
        name="exercise_platform2",
        entities={
            "exercise_platform2.program": "Training Program"
        },
        autonomy_profile={
            "program.created": "A2",
            "program.approval_requested": "A2",
            "program.approved": "A2",
            "program.activated": "A2"
        }
    )
)
