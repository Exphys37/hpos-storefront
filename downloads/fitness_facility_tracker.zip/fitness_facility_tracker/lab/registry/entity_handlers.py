from typing import Callable, Dict


class EntityHandlerRegistry:
    def __init__(self):
        self._handlers: Dict[str, Callable] = {}

    def register(self, entity_type: str, handler: Callable):
        self._handlers[entity_type] = handler

    def get(self, entity_type: str):
        return self._handlers.get(entity_type)


entity_handler_registry = EntityHandlerRegistry()
