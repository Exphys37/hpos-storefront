import json
from pathlib import Path
from typing import Any


SYSTEM_STATE_PATH = Path("control/system/system_state.json")

DEFAULT_SYSTEM_STATE = {
    "first_run_complete": False,
    "deployment_mode": "local",
    "admin_key_set": False,
}


def load_system_state() -> dict[str, Any]:
    if not SYSTEM_STATE_PATH.exists():
        return DEFAULT_SYSTEM_STATE.copy()

    try:
        raw = SYSTEM_STATE_PATH.read_text().strip()
        if not raw:
            return DEFAULT_SYSTEM_STATE.copy()
        data = json.loads(raw)
    except Exception:
        return DEFAULT_SYSTEM_STATE.copy()

    state = DEFAULT_SYSTEM_STATE.copy()
    if isinstance(data, dict):
        state.update(data)

    return state


def save_system_state(state: dict[str, Any]) -> dict[str, Any]:
    SYSTEM_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    merged = DEFAULT_SYSTEM_STATE.copy()
    merged.update(state)
    SYSTEM_STATE_PATH.write_text(json.dumps(merged, indent=2) + "\n")
    return merged


def mark_first_run_complete(deployment_mode: str = "local", admin_key_set: bool = True) -> dict[str, Any]:
    return save_system_state(
        {
            "first_run_complete": True,
            "deployment_mode": deployment_mode,
            "admin_key_set": admin_key_set,
        }
    )
