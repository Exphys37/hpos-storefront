from fastapi import Depends

from auth.dependencies import require_admin_token

from fastapi import APIRouter
from sqlmodel import select
from core.database import get_session
from runtime.models import TaskRecord
from supervisory_runtime.models import SupervisionRecord
from runtime.incidents import IncidentRecord
from runtime.safe_mode import safe_mode

from fastapi import Depends

router = APIRouter(
    prefix="/control",
    tags=["control"],
    dependencies=[Depends(require_admin_token)]
)

@router.get("/health")
def health():
    return {"status": "ok"}

@router.get("/metrics")
def metrics():
    with get_session() as session:
        return {
            "total_tasks": len(session.exec(select(TaskRecord)).all()),
            "pending_tasks": len(session.exec(select(TaskRecord).where(TaskRecord.status == "pending")).all()),
            "failed_tasks": len(session.exec(select(TaskRecord).where(TaskRecord.status == "failed")).all()),
            "safe_mode": safe_mode.is_enabled(),
        }

@router.get("/tasks")
def tasks():
    with get_session() as session:
        return session.exec(select(TaskRecord)).all()

@router.get("/supervision")
def supervision():
    with get_session() as session:
        return session.exec(select(SupervisionRecord)).all()

@router.get("/incidents")
def incidents():
    with get_session() as session:
        return session.exec(select(IncidentRecord)).all()

@router.get("/safe-mode")
def safe_mode_status():
    return {"safe_mode": safe_mode.is_enabled()}

from typing import List
from runtime.models import TaskRecord
from supervisory_runtime.models import SupervisionRecord
from runtime.incidents import IncidentRecord


@router.post("/tasks/retry")
def bulk_retry_tasks(task_ids: List[str]):
    with get_session() as session:
        tasks = session.exec(
            select(TaskRecord).where(TaskRecord.id.in_(task_ids))
        ).all()

        for task in tasks:
            if task.status == "failed":
                task.status = "pending"
                task.retry_count = 0
                session.add(task)

        session.commit()

        return {"retried": [t.id for t in tasks]}

@router.post("/supervision/approve")
def bulk_approve_supervision(record_ids: List[str]):
    with get_session() as session:
        records = session.exec(
            select(SupervisionRecord).where(SupervisionRecord.id.in_(record_ids))
        ).all()

        for record in records:
            record.status = "approved"
            session.add(record)

        session.commit()

        return {"approved": [r.id for r in records]}

@router.post("/incidents/resolve")
def bulk_resolve_incidents(incident_ids: List[str]):
    with get_session() as session:
        incidents = session.exec(
            select(IncidentRecord).where(IncidentRecord.id.in_(incident_ids))
        ).all()

        for incident in incidents:
            incident.resolved = True
            session.add(incident)

        session.commit()

        return {"resolved": [i.id for i in incidents]}

from hp_platform.project_registry import project_registry

@router.get("/projects")
def list_projects():
    return project_registry.list_projects()
