#!/usr/bin/env bash
set -e

cd "$HOME/lab_local"

URL="http://127.0.0.1:8020/"
LOG_FILE="control/runtime/control_center_watchdog.log"

mkdir -p control/runtime

timestamp() {
  date -u +"%Y-%m-%dT%H:%M:%SZ"
}

if curl -fsS --max-time 2 "$URL" >/dev/null 2>&1; then
  echo "$(timestamp) healthy" >> "$LOG_FILE"
  exit 0
fi

echo "$(timestamp) unhealthy - restarting control center" >> "$LOG_FILE"
./hp-os-control-center.sh stop >> "$LOG_FILE" 2>&1 || true
./hp-os-control-center.sh >> "$LOG_FILE" 2>&1
echo "$(timestamp) restart attempted" >> "$LOG_FILE"
