import json
import os
import secrets
from pathlib import Path

from fastapi import Header, HTTPException


API_KEY_REGISTRY_PATH = Path("control/security/api_keys.json")


def require_admin(x_role: str = Header(...)):
    if x_role.lower() != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")


def load_api_key_registry() -> dict:
    if not API_KEY_REGISTRY_PATH.exists():
        return {"keys": []}

    try:
        data = json.loads(API_KEY_REGISTRY_PATH.read_text())
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"API key registry unreadable: {e}")

    if not isinstance(data, dict):
        raise HTTPException(status_code=500, detail="API key registry invalid")

    keys = data.get("keys", [])
    if not isinstance(keys, list):
        raise HTTPException(status_code=500, detail="API key registry invalid")

    return data


def resolve_api_key_record(api_key: str | None) -> dict | None:
    if not api_key:
        return None

    registry = load_api_key_registry()
    for record in registry.get("keys", []):
        if not isinstance(record, dict):
            continue
        if record.get("key") == api_key:
            return record

    return None


def require_api_key(x_api_key: str | None = Header(default=None)):
    record = resolve_api_key_record(x_api_key)
    if record is not None:
        if not record.get("active", False):
            raise HTTPException(status_code=403, detail="Forbidden")
        return

    expected = os.getenv("HPOS_API_KEY")
    if not expected and not API_KEY_REGISTRY_PATH.exists():
        raise HTTPException(status_code=500, detail="API key not configured")

    if expected and x_api_key == expected:
        return

    raise HTTPException(status_code=403, detail="Forbidden")

def get_api_key_registry_status() -> dict:
    registry = load_api_key_registry()
    snapshot = []

    for record in registry.get("keys", []):
        if not isinstance(record, dict):
            continue

        raw_key = str(record.get("key", ""))
        redacted_key = f"{raw_key[:4]}..." if raw_key else "missing"

        snapshot.append(
            {
                "key_prefix": redacted_key,
                "label": record.get("label"),
                "owner": record.get("owner"),
                "active": bool(record.get("active", False)),
            }
        )

    return {
        "registry_path": str(API_KEY_REGISTRY_PATH),
        "key_count": len(snapshot),
        "keys": snapshot,
        "legacy_env_key_configured": bool(os.getenv("HPOS_API_KEY")),
    }

def set_api_key_active_state(label: str, active: bool) -> dict:
    registry = load_api_key_registry()
    keys = registry.get("keys", [])

    for record in keys:
        if not isinstance(record, dict):
            continue
        if record.get("label") == label:
            record["active"] = bool(active)
            API_KEY_REGISTRY_PATH.write_text(json.dumps(registry, indent=2) + "\n")
            return {
                "label": label,
                "active": bool(record.get("active", False)),
            }

    raise HTTPException(status_code=404, detail="API key label not found")

def create_api_key(label: str, owner: str | None = None, active: bool = True) -> dict:
    registry = load_api_key_registry()
    keys = registry.setdefault("keys", [])

    for record in keys:
        if not isinstance(record, dict):
            continue
        if record.get("label") == label:
            raise HTTPException(status_code=409, detail="API key label already exists")

    raw_key = secrets.token_urlsafe(24)

    record = {
        "key": raw_key,
        "label": label,
        "owner": owner,
        "active": bool(active),
    }

    keys.append(record)
    API_KEY_REGISTRY_PATH.write_text(json.dumps(registry, indent=2) + "\n")

    return {
        "key": raw_key,
        "label": label,
        "owner": owner,
        "active": bool(active),
    }

def require_admin_api_key(x_api_key: str | None = Header(default=None)):
    record = resolve_api_key_record(x_api_key)
    if record is None:
        raise HTTPException(status_code=403, detail="Forbidden")

    if not record.get("active", False):
        raise HTTPException(status_code=403, detail="Forbidden")

    if not record.get("admin", False):
        raise HTTPException(status_code=403, detail="Admin privileges required")

