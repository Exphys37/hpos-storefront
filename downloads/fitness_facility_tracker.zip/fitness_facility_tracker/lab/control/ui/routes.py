from fastapi import APIRouter, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from control.security.guards import require_admin
from core.database import get_session
from sqlmodel import select
from runtime.models import TaskRecord
from supervisory_runtime.models import SupervisionRecord
from runtime.incidents import IncidentRecord
from runtime.safe_mode import safe_mode

router = APIRouter(prefix="/ui", tags=["ui"], )
templates = Jinja2Templates(directory="lab/control/ui/templates")


@router.get("/", response_class=HTMLResponse)
def dashboard(request: Request):
    if "admin_token" not in request.session:

        return RedirectResponse(url="/ui/login", status_code=302)

    with get_session() as session:
        tasks = session.exec(select(TaskRecord)).all()
        supervision = session.exec(select(SupervisionRecord)).all()
        incidents = session.exec(select(IncidentRecord)).all()

        return templates.TemplateResponse(
            "dashboard.html",
            {
                "request": request,
                "tasks": tasks,
                "supervision": supervision,
                "incidents": incidents,
                "safe_mode": safe_mode.is_enabled()
            }
        )

from fastapi import Form
from fastapi.responses import RedirectResponse
from auth.models import AdminUser


@router.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@router.post("/login")
def login(request: Request, token: str = Form(...)):
    from sqlmodel import select

    with get_session() as session:
        user = session.exec(
            select(AdminUser).where(
                AdminUser.api_token == token,
                AdminUser.active == True
            )
        ).first()

        if not user:
            return templates.TemplateResponse(
                "login.html",
                {"request": request, "error": "Invalid token"}
            )

        request.session["admin_token"] = token
        return RedirectResponse(url="/ui/", status_code=302)

from fastapi.responses import RedirectResponse
from fastapi import Form
import requests

@router.post("/retry-task")
def retry_task(request: Request, task_id: str = Form(...)):
    token = request.session.get("admin_token")
    requests.post(
        "http://127.0.0.1:8001/control/tasks/retry",
        headers={"Authorization": f"Bearer {token}"},
        json=[task_id]
    )
    return RedirectResponse("/ui/", status_code=302)


@router.post("/approve-supervision")
def approve_supervision(request: Request, record_id: str = Form(...)):
    token = request.session.get("admin_token")
    requests.post(
        "http://127.0.0.1:8001/control/supervision/approve",
        headers={"Authorization": f"Bearer {token}"},
        json=[record_id]
    )
    return RedirectResponse("/ui/", status_code=302)


@router.post("/resolve-incident")
def resolve_incident(request: Request, incident_id: str = Form(...)):
    token = request.session.get("admin_token")
    requests.post(
        "http://127.0.0.1:8001/control/incidents/resolve",
        headers={"Authorization": f"Bearer {token}"},
        json=[incident_id]
    )
    return RedirectResponse("/ui/", status_code=302)


@router.post("/reset-safe-mode")
def reset_safe_mode(request: Request):
    token = request.session.get("admin_token")
    requests.post(
        "http://127.0.0.1:8001/system/safe_mode/reset",
        headers={"Authorization": f"Bearer {token}"}
    )
    return RedirectResponse("/ui/", status_code=302)
