from __future__ import annotations

import json
from pathlib import Path

from control.core.file_writer import restore_file

ROOT = Path.home() / "lab_local"
MANIFEST = ROOT / "control" / "runtime" / "rollback" / "rollback_manifest.json"

if not MANIFEST.exists():
    raise SystemExit("NO_ROLLBACK_MANIFEST")

manifest = json.loads(MANIFEST.read_text())

for entry in reversed(manifest):
    backup_path = entry.get("backup_path")
    target_path = entry.get("path")
    if backup_path and target_path:
        result = restore_file(target_path, backup_path)
        print(json.dumps({
            "restored_entry": entry,
            "restore_result": result,
        }, indent=2))
        raise SystemExit(0)

raise SystemExit("NO_RESTORABLE_BACKUP_FOUND")
