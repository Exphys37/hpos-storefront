from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path


def write_file(path: str | Path, content: str) -> dict:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)

    backup_path = None
    if p.exists():
        backup_dir = Path.home() / "lab_local" / "backups" / "file_writer"
        backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
        backup_path = backup_dir / f"{p.name}.{stamp}.bak"
        backup_path.write_text(p.read_text())

    p.write_text(content)

    # verify write
    read_back = p.read_text()

    if read_back != content:
        return {
            "ok": False,
            "error": "write verification failed",
            "path": str(p),
        }

    return {
        "ok": True,
        "path": str(p),
        "bytes": len(content),
        "backup_path": str(backup_path) if backup_path else None,
    }


def restore_file(path: str | Path, backup_path: str | Path) -> dict:
    p = Path(path)
    b = Path(backup_path)

    if not b.exists():
        return {
            "ok": False,
            "error": "backup not found",
            "backup_path": str(b),
        }

    content = b.read_text()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content)

    if p.read_text() != content:
        return {
            "ok": False,
            "error": "restore verification failed",
            "path": str(p),
            "backup_path": str(b),
        }

    return {
        "ok": True,
        "path": str(p),
        "backup_path": str(b),
        "bytes": len(content),
    }

def record_rollback_entry(path: str | Path, backup_path: str | Path | None, reason: str = "") -> dict:
    import json

    rollback_dir = Path.home() / "lab_local" / "control" / "runtime" / "rollback"
    rollback_dir.mkdir(parents=True, exist_ok=True)

    manifest_path = rollback_dir / "rollback_manifest.json"
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text())
        except Exception:
            manifest = []
    else:
        manifest = []

    entry = {
        "recorded_at": datetime.now(UTC).isoformat(),
        "path": str(path),
        "backup_path": str(backup_path) if backup_path else None,
        "reason": reason,
    }
    manifest.append(entry)
    manifest_path.write_text(json.dumps(manifest, indent=2))

    return {
        "ok": True,
        "manifest_path": str(manifest_path),
        "entry": entry,
    }
