from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path.home() / "lab_local"


def ensure_root_on_path() -> Path:
    root_text = str(ROOT)
    if root_text not in sys.path:
        sys.path.insert(0, root_text)
    return ROOT
