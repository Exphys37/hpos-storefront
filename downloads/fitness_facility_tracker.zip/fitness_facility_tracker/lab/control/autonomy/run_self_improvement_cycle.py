from __future__ import annotations

import sys
from pathlib import Path

_LOCAL_ROOT = Path.home() / "lab_local"
sys.path.insert(0, str(_LOCAL_ROOT))
from control.core.bootstrap import ensure_root_on_path

ROOT = ensure_root_on_path()

import json
import sys
from pathlib import Path

ROOT = Path.home() / "lab_local"
sys.path.insert(0, str(ROOT))

from control.autonomy.next_platform_task import get_next_task
from control.autonomy.apply_platform_fix import apply_fix


def run_cycle() -> dict:
    task = get_next_task()
    if not task:
        return {"status": "no_tasks"}

    result = apply_fix(task)

    return {
        "status": "executed",
        "task_id": task.get("id"),
        "result": result,
    }


if __name__ == "__main__":
    print(json.dumps(run_cycle(), indent=2))
