from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from control.autonomy.plan_intelligence import generate_phases
from control.core.file_writer import write_file

ROOT = Path.home() / "lab_local"
PLANS_DIR = ROOT / "control" / "autonomy" / "plans"


def create_plan(project: str, request: str) -> dict:
    PLANS_DIR.mkdir(parents=True, exist_ok=True)

    now = datetime.utcnow().isoformat()

    plan = {
        "id": now.replace(":", "").replace(".", ""),
        "project": project,
        "request": request,
        "status": "in_progress",
        "phases": generate_phases(request, project)
    }

    path = PLANS_DIR / f"{plan['id']}.json"
    write_file(path, json.dumps(plan, indent=2))

    print(json.dumps(plan, indent=2))
    return plan


if __name__ == "__main__":
    create_plan(
        "fitness_facility_tracker",
        "Build full facility management system"
    )
