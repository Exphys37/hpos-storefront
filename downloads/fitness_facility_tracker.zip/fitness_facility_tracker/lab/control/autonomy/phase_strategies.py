from __future__ import annotations


def select_strategy(instruction: str, phase_name: str = "") -> str:
    text = instruction.lower()
    name = phase_name.lower()

    if "packaging" in name or "delivery" in name:
        return "packaging"

    if "validation" in name or "stabilization" in name:
        return "validation"

    if "reports" in name or "analytics" in name:
        return "reports"

    if "exports" in name:
        return "exports"

    if "check-in" in text or "check-out" in text or "core" in name:
        return "fitness_core"

    return "default"
