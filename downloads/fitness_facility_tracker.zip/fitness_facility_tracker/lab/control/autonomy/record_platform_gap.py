from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from control.core.file_writer import write_file

ROOT = Path.home() / "lab_local"
GAPS_DIR = ROOT / "control" / "autonomy" / "platform_gaps"
BACKLOG = ROOT / "control" / "autonomy" / "platform_improvement_backlog.json"


def load_backlog() -> list[dict]:
    if BACKLOG.exists():
        return json.loads(BACKLOG.read_text())
    return []


def save_backlog(items: list[dict]) -> None:
    write_file(BACKLOG, json.dumps(items, indent=2))


def record_gap(title: str, details: str, severity: str = "high") -> dict:
    GAPS_DIR.mkdir(parents=True, exist_ok=True)

    now = datetime.now(UTC).isoformat()
    gap = {
        "id": now.replace(":", "").replace(".", ""),
        "created_at": now,
        "title": title,
        "details": details,
        "severity": severity,
        "status": "open",
        "recommended_platform_change": (
            "Add autonomous failure diagnosis, platform improvement planning, "
            "guardrailed patching, validation, and retry of the original task."
        ),
    }

    gap_path = GAPS_DIR / f"{gap['id']}.json"
    write_file(gap_path, json.dumps(gap, indent=2))

    backlog = load_backlog()
    backlog.append(gap)
    save_backlog(backlog)

    print(json.dumps(gap, indent=2))
    return gap


if __name__ == "__main__":
    record_gap(
        title="Improvement applied without autonomous restart, validation, diagnosis, or retry",
        details=(
            "Fitness facility tracker improvement applied successfully, but the running app "
            "continued serving stale scaffold output until manually restarted. HP-OS also did "
            "not automatically convert the failed checkout validation into a platform upgrade task."
        ),
        severity="critical",
    )
