from __future__ import annotations

from control.autonomy.capability_registry import get_capabilities


def generate_phases(request: str, project: str = "") -> list[dict]:
    text = request.lower()
    phases: list[dict] = []
    capabilities = get_capabilities(project)

    phases.append({
        "id": 1,
        "name": "Core functionality",
        "status": "pending",
        "instruction": request,
    })

    if capabilities.get("reports") and any(word in text for word in ["report", "dashboard", "analytics", "graph", "chart"]):
        phases.append({
            "id": len(phases) + 1,
            "name": "Reports and analytics",
            "status": "pending",
            "instruction": "Add reports, dashboard metrics, analytics, and export-friendly summaries",
        })

    if capabilities.get("exports") and any(word in text for word in ["export", "csv", "download", "spreadsheet"]):
        phases.append({
            "id": len(phases) + 1,
            "name": "Exports",
            "status": "pending",
            "instruction": "Add CSV export and downloadable data outputs",
        })

    phases.append({
        "id": len(phases) + 1,
        "name": "Validation and stabilization",
        "status": "pending",
        "instruction": "Validate endpoints and ensure runtime stability",
    })

    phases.append({
        "id": len(phases) + 1,
        "name": "Packaging and delivery",
        "status": "pending",
        "instruction": "Prepare export and packaging artifacts",
    })

    return phases
