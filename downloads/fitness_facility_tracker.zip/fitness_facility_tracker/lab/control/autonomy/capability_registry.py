from __future__ import annotations

CAPABILITIES = {
    "fitness_facility_tracker": {
        "core": [
            "check-in system",
            "check-out system",
            "session tracking",
        ],
        "reports": [
            "usage reports",
            "session summaries",
            "analytics dashboard",
        ],
        "exports": [
            "csv export",
            "data download",
        ],
    }
}


def get_capabilities(project: str) -> dict:
    return CAPABILITIES.get(project, {})
