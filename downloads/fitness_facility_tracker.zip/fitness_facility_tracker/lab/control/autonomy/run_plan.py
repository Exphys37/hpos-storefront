from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

_LOCAL_ROOT = Path.home() / "lab_local"
sys.path.insert(0, str(_LOCAL_ROOT))
from control.core.bootstrap import ensure_root_on_path

ROOT = ensure_root_on_path()

from control.autonomy.phase_strategies import select_strategy
from control.core.file_writer import write_file
from control.autonomy.run_full_self_heal_cycle import run_full_cycle
from control.autonomy.record_platform_gap import record_gap

PLANS_DIR = ROOT / "control" / "autonomy" / "plans"


def load_latest_plan() -> tuple[Path, dict] | None:
    plans = sorted(PLANS_DIR.glob("*.json"), reverse=True)
    if not plans:
        return None
    path = plans[0]
    return path, json.loads(path.read_text())


def save_plan(path: Path, plan: dict) -> None:
    write_file(path, json.dumps(plan, indent=2))


def run_phase(plan: dict, phase: dict) -> dict:
    project = plan["project"]
    instruction = phase.get("instruction") or plan["request"]

    strategy = select_strategy(instruction, phase.get('name', ''))

    if strategy == "validation":
        port = "9999" if "broken port" in instruction.lower() else "8555"
        result = subprocess.run(
            ["python3", "scripts/validate_project_runtime.py", port],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
        )
        return {
            "ok": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }

    if strategy == "packaging":
        result = subprocess.run(
            ["python3", "scripts/package_project.py", project],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
        )
        return {
            "ok": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }

    if strategy == "reports":
        return {
            "ok": True,
            "strategy": "reports",
            "note": "Baseline reports already present: active users, completed sessions, recent sessions. Rich analytics pending."
        }

    if strategy == "exports":
        return {
            "ok": True,
            "strategy": "exports",
            "note": "CSV export already present at /export.csv."
        }

    result = subprocess.run(
        [
            "python3",
            "scripts/apply_project_improvement.py",
            "--project",
            project,
            "--request",
            instruction,
        ],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
    )

    return {
        "ok": result.returncode == 0,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }


def run_plan() -> dict:
    loaded = load_latest_plan()
    if not loaded:
        return {"status": "no_plan"}

    path, plan = loaded

    for phase in plan["phases"]:
        if phase["status"] == "completed":
            continue

        result = run_phase(plan, phase)

        if not result["ok"]:
            heal_result = run_full_cycle()
            retry_result = run_phase(plan, phase)

            if retry_result.get("ok"):
                phase["status"] = "completed"
                phase["result"] = retry_result
                phase["self_heal"] = heal_result
                save_plan(path, plan)
                continue

            phase["status"] = "failed"
            phase["result"] = retry_result
            phase["self_heal"] = heal_result

            gap = record_gap(
                title=f"Phase failed after self-heal: {phase.get('name')}",
                details=f"Project {plan.get('project')} phase failed after retry. Instruction: {phase.get('instruction')}. Result: {retry_result}",
                severity="high",
            )
            phase["platform_gap"] = gap

            save_plan(path, plan)
            return {"status": "failed", "phase": phase, "result": retry_result, "self_heal": heal_result, "platform_gap": gap}

        phase["status"] = "completed"
        phase["result"] = result
        save_plan(path, plan)

    plan["status"] = "completed"
    save_plan(path, plan)

    return {"status": "completed", "plan": plan}


if __name__ == "__main__":
    print(json.dumps(run_plan(), indent=2))
