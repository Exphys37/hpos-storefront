from __future__ import annotations

import sys
from pathlib import Path
from control.core.file_writer import write_file

_LOCAL_ROOT = Path.home() / "lab_local"
sys.path.insert(0, str(_LOCAL_ROOT))
from control.core.bootstrap import ensure_root_on_path

ROOT = ensure_root_on_path()

import json
import subprocess
import sys
import time
from pathlib import Path
from control.core.file_writer import write_file

ROOT = Path.home() / "lab_local"
sys.path.insert(0, str(ROOT))
CONTROL_PORT = "8020"
BACKLOG = ROOT / "control" / "autonomy" / "platform_improvement_backlog.json"


def restart_project(project_name: str) -> dict:
    try:
        result = subprocess.run(
            ["curl", "-s", "-X", "POST", f"http://127.0.0.1:{CONTROL_PORT}/projects/{project_name}/restart"],
            capture_output=True,
            text=True,
        )
        return {"ok": True, "stdout": result.stdout, "stderr": result.stderr}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def health_check(port: str, attempts: int = 10, delay: float = 1.0) -> bool:
    for _ in range(attempts):
        try:
            result = subprocess.run(
                ["curl", "-s", f"http://localhost:{port}/health"],
                capture_output=True,
                text=True,
            )
            if "ok" in result.stdout:
                return True
        except Exception:
            pass
        time.sleep(delay)
    return False



def mark_task_resolved(task_id: str, result: dict) -> None:
    if not BACKLOG.exists():
        return
    items = json.loads(BACKLOG.read_text())
    for item in items:
        if item.get("id") == task_id:
            item["status"] = "resolved"
            item["resolved_result"] = result
            break
    write_file(BACKLOG, json.dumps(items, indent=2))

def apply_fix(task: dict) -> dict:
    title = task.get("title", "")

    if "restart" in title.lower():
        # hardcoded for now — next step will generalize this
        project_name = "fitness_facility_tracker"
        port = "8555"

        restart = restart_project(project_name)
        healthy = health_check(port)

        result = {
            "action": "restart_and_validate",
            "restart": restart,
            "healthy": healthy,
        }

        if healthy:
            mark_task_resolved(task.get("id", ""), result)

        return result

    return {"action": "no_known_fix"}


if __name__ == "__main__":
    from control.autonomy.next_platform_task import get_next_task

    task = get_next_task()
    if not task:
        print("No task")
    else:
        result = apply_fix(task)
        print(json.dumps(result, indent=2))
