from __future__ import annotations

import json
from pathlib import Path

ROOT = Path.home() / "lab_local"
BACKLOG = ROOT / "control" / "autonomy" / "platform_improvement_backlog.json"


def load_backlog() -> list[dict]:
    if BACKLOG.exists():
        return json.loads(BACKLOG.read_text())
    return []


def get_next_task() -> dict | None:
    backlog = load_backlog()
    if not backlog:
        return None

    # prioritize critical > high > medium > low
    priority = {"critical": 0, "high": 1, "medium": 2, "low": 3}

    backlog = sorted(
        [b for b in backlog if b.get("status") == "open"],
        key=lambda x: priority.get(x.get("severity", "medium"), 2),
    )

    return backlog[0] if backlog else None


if __name__ == "__main__":
    task = get_next_task()
    print(json.dumps(task, indent=2) if task else "No tasks")
