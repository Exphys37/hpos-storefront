from __future__ import annotations

import sys
from pathlib import Path

_LOCAL_ROOT = Path.home() / "lab_local"
sys.path.insert(0, str(_LOCAL_ROOT))
from control.core.bootstrap import ensure_root_on_path

ROOT = ensure_root_on_path()

import json
import sys
from pathlib import Path

ROOT = Path.home() / "lab_local"
sys.path.insert(0, str(ROOT))

from control.autonomy.run_self_improvement_cycle import run_cycle
from control.autonomy.retry_last_task import retry


def run_full_cycle() -> dict:
    improvement = run_cycle()

    if improvement.get("status") == "no_tasks":
        return {
            "status": "no_improvements_needed",
            "retry": None,
        }

    retry_result = retry()

    return {
        "status": "self_heal_executed",
        "improvement": improvement,
        "retry": retry_result,
    }


if __name__ == "__main__":
    print(json.dumps(run_full_cycle(), indent=2))
