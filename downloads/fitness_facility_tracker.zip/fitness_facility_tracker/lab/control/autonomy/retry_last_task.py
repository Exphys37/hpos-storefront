from __future__ import annotations

import json
from pathlib import Path
import subprocess

ROOT = Path.home() / "lab_local"
PROJECTS_DIR = ROOT / "projects"


def load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text())
    except Exception:
        return {}


def find_last_project_request() -> tuple[str, str] | None:
    candidates: list[tuple[float, str, str]] = []

    for task_path in PROJECTS_DIR.rglob("task.json"):
        data = load_json(task_path)
        request = data.get("request") or data.get("summary")
        task_type = data.get("task_type", "")

        if not request:
            continue

        try:
            project_name = task_path.relative_to(PROJECTS_DIR).parts[0]
        except Exception:
            continue

        priority_bonus = 1000000000 if task_type == "project_improvement" else 0
        score = task_path.stat().st_mtime + priority_bonus
        candidates.append((score, project_name, request))

    if not candidates:
        return None

    candidates.sort(reverse=True)
    _, project, request = candidates[0]
    return project, request


def retry() -> dict:
    item = find_last_project_request()
    if not item:
        return {"status": "no_previous_task"}

    project, request = item

    result = subprocess.run(
        [
            "python3",
            "scripts/apply_project_improvement.py",
            "--project",
            project,
            "--request",
            request,
        ],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
    )

    return {
        "project": project,
        "request": request,
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }


if __name__ == "__main__":
    print(json.dumps(retry(), indent=2))
