import os
from sqlmodel import SQLModel, create_engine, Session

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "sqlite:///lab.db"
)

engine = create_engine(DATABASE_URL, echo=False)

def init_db():
    import runtime.models  # ensure SQLModel tables are registered
    import runtime.incidents  # ensure incident tables are registered
    SQLModel.metadata.create_all(engine)

def get_session():
    return Session(engine)
