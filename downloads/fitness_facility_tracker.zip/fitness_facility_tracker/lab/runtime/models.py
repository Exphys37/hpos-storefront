from sqlmodel import SQLModel, Field
from typing import Optional
from datetime import datetime
import uuid


class TaskRecord(SQLModel, table=True):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    entity_type: str
    entity_id: str
    execution_key: str  # unique execution guard
    status: str = "pending"  # pending | running | completed | failed
    retry_count: int = 0
    max_retries: int = 3
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None


class SupportCase(SQLModel, table=True):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)

    # customer context
    customer_email: Optional[str] = None
    product_name: Optional[str] = None
    product_version: Optional[str] = None

    # issue
    title: str
    description: str
    severity: str = "medium"  # low | medium | high | critical

    # lifecycle
    status: str = "reported"
    # reported → triaged → reproducing → reproduced → repair_planned
    # → repairing → validating → patch_ready → delivered → closed → failed

    # environment / reproduction
    environment_info: Optional[str] = None
    reproduction_notes: Optional[str] = None

    # repair / patch
    repair_summary: Optional[str] = None
    patch_artifact_path: Optional[str] = None
    delivery_method: Optional[str] = None
    delivery_target: Optional[str] = None
    delivered_artifact_fingerprint: Optional[str] = None
    customer_verified_at: Optional[datetime] = None
    rollback_artifact_path: Optional[str] = None
    rollback_reason: Optional[str] = None

    # timestamps
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None
    closed_at: Optional[datetime] = None
