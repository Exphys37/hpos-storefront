from sqlmodel import select
from autonomy.classifier import classify_event
from runtime.models import TaskRecord
from core.database import get_session


def dispatch(event):
    level = classify_event(event)

    if level != "A1":
        return

    execution_key = f"{event.payload.get('entity_type')}:{event.payload.get('entity_id')}"

    with get_session() as session:
        existing = session.exec(
            select(TaskRecord).where(TaskRecord.execution_key == execution_key)
        ).first()

        if existing:
            print(f"[DISPATCHER] Duplicate task prevented for {execution_key}")
            return

        print(f"[DISPATCHER] Persisting A1 task for {execution_key}")

        task = TaskRecord(
            entity_type=event.payload.get("entity_type"),
            entity_id=event.payload.get("entity_id"),
            execution_key=execution_key,
        )

        session.add(task)
        session.commit()


def dispatch_event(event):
    return dispatch(event)
