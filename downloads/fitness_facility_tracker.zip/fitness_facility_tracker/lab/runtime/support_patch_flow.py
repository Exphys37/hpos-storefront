import json
import hashlib
import shutil
from datetime import datetime
from pathlib import Path

from scripts.package_project import package_project
from runtime.support_cases import attach_case_repair_result, mark_support_case_delivered


def build_support_patch(
    case_id: str,
    project_name: str,
    repair_summary: str,
    export_mode: str = "validated_source_bundle",
) -> dict:
    result = package_project(project_name, export_mode=export_mode)

    updated_case = attach_case_repair_result(
        case_id=case_id,
        repair_summary=repair_summary,
        patch_artifact_path=result["archive_path"],
        status="patch_ready",
    )

    return {
        "case_id": updated_case.id,
        "status": updated_case.status,
        "repair_summary": updated_case.repair_summary,
        "patch_artifact_path": updated_case.patch_artifact_path,
        "packaging_result": result,
        "built_at_utc": datetime.utcnow().isoformat(),
    }

def rollback_support_case(
    case_id: str,
    rollback_artifact_path: str,
    reason: str,
) -> dict:
    from runtime.support_cases import update_support_case_status
    from core.database import get_session
    from runtime.models import SupportCase

    with get_session() as session:
        case = session.get(SupportCase, case_id)
        if not case:
            raise ValueError(f"SUPPORT_CASE_NOT_FOUND: {case_id}")

        case.status = "rolled_back"
        case.rollback_artifact_path = rollback_artifact_path
        case.rollback_reason = reason
        case.updated_at = datetime.utcnow()

        session.add(case)
        session.commit()
        session.refresh(case)

        return {
            "case_id": case.id,
            "status": case.status,
            "rollback_artifact_path": case.rollback_artifact_path,
            "rollback_reason": case.rollback_reason,
            "rolled_back_at_utc": datetime.utcnow().isoformat(),
        }

def compute_file_fingerprint(file_path: str) -> str:
    path = Path(file_path)
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"ARTIFACT_NOT_FOUND: {file_path}")

    hasher = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def deliver_support_patch(
    case_id: str,
    patch_artifact_path: str,
    delivery_target: str,
    delivery_method: str = "local_outbound_copy",
) -> dict:
    source = Path(patch_artifact_path)
    if not source.exists() or not source.is_file():
        raise FileNotFoundError(f"PATCH_ARTIFACT_NOT_FOUND: {patch_artifact_path}")

    outbound_root = Path("outbound/support")
    outbound_root.mkdir(parents=True, exist_ok=True)

    delivered_name = f"{case_id}_{source.name}"
    delivered_path = outbound_root / delivered_name
    shutil.copy2(source, delivered_path)

    delivered_fingerprint = compute_file_fingerprint(str(delivered_path))

    updated_case = mark_support_case_delivered(
        case_id=case_id,
        delivery_method=delivery_method,
        delivery_target=delivery_target,
        delivered_artifact_fingerprint=delivered_fingerprint,
    )

    return {
        "case_id": updated_case.id,
        "status": updated_case.status,
        "delivery_method": updated_case.delivery_method,
        "delivery_target": updated_case.delivery_target,
        "delivered_artifact_path": str(delivered_path),
        "delivered_artifact_fingerprint": delivered_fingerprint,
        "delivered_at_utc": datetime.utcnow().isoformat(),
    }

