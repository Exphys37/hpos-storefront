from runtime.incidents import IncidentRecord
from core.database import get_session


class SafeModeController:
    def __init__(self):
        self.enabled = False
        self.failure_count = 0
        self.failure_threshold = 5

    def record_failure(self):
        self.failure_count += 1
        print(f"[SAFE MODE] Failure count: {self.failure_count}")

        if self.failure_count >= self.failure_threshold:
            self.enabled = True
            print("[SAFE MODE] Activated")

            with get_session() as session:
                incident = IncidentRecord(
                    type="SAFE_MODE_TRIGGER",
                    description="Failure threshold exceeded"
                )
                session.add(incident)
                session.commit()

    def reset(self):
        self.enabled = False
        self.failure_count = 0
        print("[SAFE MODE] Reset")

    def is_enabled(self):
        return self.enabled


safe_mode = SafeModeController()
