import logging

import threading
import time
from datetime import datetime
from sqlmodel import select
from runtime.models import TaskRecord
from core.database import get_session
from registry.entity_handlers import entity_handler_registry
from supervisory_runtime.models import SupervisionRecord
from runtime.safe_mode import safe_mode
from runtime.lifecycle import lifecycle


class Worker:

    def __init__(self):
        self.thread = None

    def start(self):
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()

    def run(self):
        logging.info("[WORKER] Persistent Worker Started")

        while not lifecycle.is_shutdown():

            if safe_mode.is_enabled():
                time.sleep(1)
                continue

            with get_session() as session:
                task = session.exec(
                    select(TaskRecord).where(TaskRecord.status == "pending")
                ).first()

                if task:
                    logging.info(f"[WORKER] Executing {task.entity_type}:{task.entity_id}")
                    task.status = "running"
                    task.updated_at = datetime.utcnow()
                    session.add(task)
                    session.commit()

                    handler = entity_handler_registry.get(task.entity_type)

                    try:
                        if handler:
                            handler(task.entity_id)
                            task.status = "completed"
                            logging.info(f"[WORKER] Completed {task.entity_id}")
                        else:
                            raise Exception("No handler registered")

                    except Exception as e:
                        task.retry_count += 1
                        logging.info(f"[WORKER] Failed ({task.retry_count}/{task.max_retries}): {e}")
                        safe_mode.record_failure()

                        if task.retry_count >= task.max_retries:
                            task.status = "failed"
                            logging.info("[WORKER] Max retries reached, escalating")

                            escalation = SupervisionRecord(
                                entity_type=task.entity_type,
                                entity_id=task.entity_id,
                                event_type="task.failed",
                                autonomy_level="A3"
                            )
                            session.add(escalation)
                        else:
                            task.status = "pending"

                    task.updated_at = datetime.utcnow()
                    session.add(task)
                    session.commit()

            time.sleep(1)

        logging.info("[WORKER] Graceful shutdown complete")


worker = Worker()
