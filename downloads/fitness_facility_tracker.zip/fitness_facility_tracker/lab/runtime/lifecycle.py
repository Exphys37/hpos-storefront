import threading


class LifecycleController:
    def __init__(self):
        self.shutdown_requested = False
        self.lock = threading.Lock()

    def request_shutdown(self):
        with self.lock:
            self.shutdown_requested = True
            print("[LIFECYCLE] Shutdown requested")

    def is_shutdown(self):
        with self.lock:
            return self.shutdown_requested


lifecycle = LifecycleController()
