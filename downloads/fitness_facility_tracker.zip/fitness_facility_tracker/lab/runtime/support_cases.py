from datetime import datetime
from typing import Optional

from sqlmodel import select

from core.database import get_session
from runtime.models import SupportCase


def create_support_case(
    title: str,
    description: str,
    customer_email: Optional[str] = None,
    product_name: Optional[str] = None,
    product_version: Optional[str] = None,
    severity: str = "medium",
    environment_info: Optional[str] = None,
) -> SupportCase:
    case = SupportCase(
        title=title,
        description=description,
        customer_email=customer_email,
        product_name=product_name,
        product_version=product_version,
        severity=severity,
        environment_info=environment_info,
        status="reported",
        updated_at=datetime.utcnow(),
    )
    with get_session() as session:
        session.add(case)
        session.commit()
        session.refresh(case)
        return case


def list_support_cases() -> list[SupportCase]:
    with get_session() as session:
        return list(session.exec(select(SupportCase).order_by(SupportCase.created_at.desc())))


def update_support_case_status(case_id: str, status: str) -> SupportCase:
    with get_session() as session:
        case = session.get(SupportCase, case_id)
        if not case:
            raise ValueError(f"SUPPORT_CASE_NOT_FOUND: {case_id}")
        case.status = status
        case.updated_at = datetime.utcnow()
        session.add(case)
        session.commit()
        session.refresh(case)
        return case

def attach_case_repair_result(
    case_id: str,
    repair_summary: str,
    patch_artifact_path: Optional[str] = None,
    status: str = "patch_ready",
) -> SupportCase:
    with get_session() as session:
        case = session.get(SupportCase, case_id)
        if not case:
            raise ValueError(f"SUPPORT_CASE_NOT_FOUND: {case_id}")
        case.repair_summary = repair_summary
        case.patch_artifact_path = patch_artifact_path
        case.status = status
        case.updated_at = datetime.utcnow()
        session.add(case)
        session.commit()
        session.refresh(case)
        return case

def attach_case_repair_from_runtime_artifacts(
    case_id: str,
    runtime_diagnosis: dict | None,
    runtime_repair_plan: dict | None,
    runtime_repair_execution: dict | None,
    patch_artifact_path: Optional[str] = None,
) -> SupportCase:
    diagnosis_type = (runtime_diagnosis or {}).get("type") or (runtime_repair_plan or {}).get("error_type") or "issue"
    symbol = (runtime_diagnosis or {}).get("symbol") or (runtime_repair_plan or {}).get("symbol")
    action_count = len((runtime_repair_plan or {}).get("actions", []) or [])
    success = bool((runtime_repair_execution or {}).get("success", False))

    summary = f"{diagnosis_type.replace('_', ' ')}"
    if symbol:
        summary += f" on '{symbol}'"
    if action_count:
        summary += f"; {action_count} repair action"
        if action_count != 1:
            summary += "s"
    summary += "; verified successfully" if success else "; verification failed"

    status = "patch_ready" if success else "failed"

    return attach_case_repair_result(
        case_id=case_id,
        repair_summary=summary,
        patch_artifact_path=patch_artifact_path,
        status=status,
    )

def mark_support_case_delivered(
    case_id: str,
    delivery_method: Optional[str] = None,
    delivery_target: Optional[str] = None,
    delivered_artifact_fingerprint: Optional[str] = None,
) -> SupportCase:
    with get_session() as session:
        case = session.get(SupportCase, case_id)
        if not case:
            raise ValueError(f"SUPPORT_CASE_NOT_FOUND: {case_id}")
        case.status = "delivered"
        now = datetime.utcnow()
        case.delivered_at = now
        case.updated_at = now
        if delivery_method is not None:
            case.delivery_method = delivery_method
        if delivery_target is not None:
            case.delivery_target = delivery_target
        if delivered_artifact_fingerprint is not None:
            case.delivered_artifact_fingerprint = delivered_artifact_fingerprint
        session.add(case)
        session.commit()
        session.refresh(case)
        return case


def close_support_case(case_id: str) -> SupportCase:
    with get_session() as session:
        case = session.get(SupportCase, case_id)
        if not case:
            raise ValueError(f"SUPPORT_CASE_NOT_FOUND: {case_id}")
        case.status = "closed"
        now = datetime.utcnow()
        if case.delivered_at is None:
            case.delivered_at = now
        case.closed_at = now
        case.updated_at = now
        session.add(case)
        session.commit()
        session.refresh(case)
        return case

def mark_support_case_verified(case_id: str, auto_close: bool = True) -> SupportCase:
    with get_session() as session:
        case = session.get(SupportCase, case_id)
        if not case:
            raise ValueError(f"SUPPORT_CASE_NOT_FOUND: {case_id}")
        now = datetime.utcnow()
        case.customer_verified_at = now
        case.updated_at = now
        if auto_close:
            if case.delivered_at is None:
                case.delivered_at = now
            case.status = "closed"
            case.closed_at = now
        else:
            case.status = "verified"
        session.add(case)
        session.commit()
        session.refresh(case)
        return case

