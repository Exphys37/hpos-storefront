from event_bus.events import BaseEvent
from registry.projects import project_registry


def classify_event(event: BaseEvent) -> str:
    """
    Determine autonomy level using project registry.
    Default to A3 if not defined.
    """

    project = project_registry.get(event.source)
    print("AUTONOMY PROFILE:", project.autonomy_profile if project else None)

    if not project:
        return "A3"

    autonomy = project.autonomy_profile.get(event.event_type)

    if not autonomy:
        return "A3"

    return autonomy


def autonomy_handler(event: BaseEvent):
    level = classify_event(event)
    print(f"[AUTONOMY] {event.event_type} classified as {level}")
