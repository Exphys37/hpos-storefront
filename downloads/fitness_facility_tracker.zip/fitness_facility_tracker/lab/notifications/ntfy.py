import requests
import json
import logging

NTFY_TOPIC = "https://ntfy.sh/exphys-lab-alerts"

def send_notification(title: str, message: str, priority: str = "default"):
    try:
        requests.post(
            NTFY_TOPIC,
            data=message.encode("utf-8"),
            headers={
                "Title": title,
                "Priority": priority
            },
            timeout=5
        )
    except Exception as e:
        logging.error(f"[NTFY] Failed to send notification: {e}")
