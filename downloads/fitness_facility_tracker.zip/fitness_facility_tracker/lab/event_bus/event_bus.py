from typing import Callable, Dict, List, Type
from event_bus.events import BaseEvent


class EventBus:
    def __init__(self):
        self._handlers: Dict[str, List[Callable[[BaseEvent], None]]] = {}

    def register(self, event_type: str, handler: Callable[[BaseEvent], None]):
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        self._handlers[event_type].append(handler)

    def emit(self, event: BaseEvent):
        handlers = self._handlers.get(event.event_type, [])
        for handler in handlers:
            handler(event)


# Global singleton (platform-level)
event_bus = EventBus()
