from event_bus.events import BaseEvent


def log_event(event: BaseEvent):
    print(f"[EVENT] {event.event_type} | source={event.source} | payload={event.payload}")
