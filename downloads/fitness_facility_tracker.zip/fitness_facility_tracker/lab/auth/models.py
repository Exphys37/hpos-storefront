from sqlmodel import SQLModel, Field
from datetime import datetime
import uuid


class AdminUser(SQLModel, table=True):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    username: str
    api_token: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    active: bool = True
