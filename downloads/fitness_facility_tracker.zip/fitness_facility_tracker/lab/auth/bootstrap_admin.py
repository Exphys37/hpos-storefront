import secrets
from lab.core.database import get_session
from lab.auth.models import AdminUser

username = "admin"
token = secrets.token_hex(32)

with get_session() as session:
    user = AdminUser(username=username, api_token=token)
    session.add(user)
    session.commit()

print("Admin created.")
print("API Token:", token)
