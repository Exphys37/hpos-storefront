from fastapi import Header, HTTPException
from sqlmodel import select
from core.database import get_session
from auth.models import AdminUser


def require_admin_token(authorization: str = Header(...)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid auth header")

    token = authorization.split(" ")[1]

    with get_session() as session:
        user = session.exec(
            select(AdminUser).where(
                AdminUser.api_token == token,
                AdminUser.active == True
            )
        ).first()

        if not user:
            raise HTTPException(status_code=403, detail="Invalid token")

    return user
