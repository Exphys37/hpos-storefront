# Project: fitness_facility_tracker

Type:
- application | research | infrastructure

Purpose:
- One or two sentences describing what this project exists to do

Non-Goals:
- Explicitly state what this project must NOT do

Domain:
- performance | medical-adjacent | research | tooling | other

Constraints:
- Safety constraints
- Regulatory constraints
- Interpretation limits

Governance:
- Subject to HP-OS UDOSS v1
- Autonomy governed by compiler enforcement
- Human-in-the-loop required at A2 boundaries

Notes:
- Optional clarifications or context


Generated Brief
---------------
Business Goal:
Track facility user check-in and check-out activity, generate user reports and facility usage reports for operational insight and grant reporting.

Target Users:
Fitness facility managers, staff, and program administrators

Deployment Type:
internal_web_app

Required Features:
- User check-in and check-out system
- Track session duration
- Store user activity history
- Generate user reports
- Generate facility usage reports
- Export reports to CSV
- Basic dashboard showing usage trends
- Health endpoint
