from sqlmodel import SQLModel, Field
from typing import Optional
from datetime import datetime
import uuid


class SupervisionRecord(SQLModel, table=True):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()), primary_key=True)
    entity_type: str
    entity_id: str
    event_type: str
    autonomy_level: str
    status: str = "pending"  # pending | approved | rejected
    created_at: datetime = Field(default_factory=datetime.utcnow)
    reviewed_at: Optional[datetime] = None
