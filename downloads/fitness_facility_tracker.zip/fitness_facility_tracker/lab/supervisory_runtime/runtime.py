from autonomy.classifier import classify_event
from runtime.dispatcher import dispatch_event
from notifications.ntfy import send_notification
from core.database import get_session
from supervisory_runtime.models import SupervisionRecord
from datetime import datetime


class SupervisoryRuntime:

    def handle_event(self, event):
        autonomy = classify_event(event)
        normalized = {part.strip() for part in str(autonomy).split("/") if part.strip()}

        if normalized & {"A2", "A3"}:
            self._create_supervision(event, autonomy)
            return

        if normalized & {"A0", "A1"}:
            dispatch_event(event)
            return

        raise Exception(f"Unknown autonomy level: {autonomy}")

    def _create_supervision(self, event, autonomy):
        db = get_session()

        supervision = SupervisionRecord(
            entity_type=event.payload.get("entity_type"),
            entity_id=event.payload.get("entity_id"),
            event_type=event.event_type,
            autonomy_level=autonomy,
            status="pending",
            created_at=datetime.utcnow()
        )

        db.add(supervision)
        db.commit()
        db.refresh(supervision)

        send_notification(
            title="Supervision Required",
            message=f"{event.event_type} requires approval (ID: {supervision.id})"
        )

        db.close()

    def approve(self, supervision_id):
        db = get_session()
        supervision = db.query(SupervisionRecord).get(supervision_id)

        if not supervision:
            db.close()
            raise Exception("Supervision not found")

        if supervision.status != "pending":
            db.close()
            return  # idempotent

        supervision.status = "approved"
        supervision.approved_at = datetime.utcnow()
        db.commit()

        # Reconstruct event and dispatch
        event = self._rebuild_event(supervision)
        dispatch_event(event)

        db.close()

    def reject(self, supervision_id):
        db = get_session()
        supervision = db.query(SupervisionRecord).get(supervision_id)

        if not supervision:
            db.close()
            raise Exception("Supervision not found")

        if supervision.status != "pending":
            db.close()
            return  # idempotent

        supervision.status = "rejected"
        supervision.rejected_at = datetime.utcnow()
        db.commit()

        db.close()

    def _rebuild_event(self, supervision):
        from event_bus.events import BaseEvent

        return BaseEvent(
            event_type=supervision.event_type,
            entity_id=supervision.entity_id,
            payload=supervision.payload
        )

supervisory_runtime = SupervisoryRuntime()
